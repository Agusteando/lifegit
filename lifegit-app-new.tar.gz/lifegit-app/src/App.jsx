import React, { useState, useEffect } from 'react';
import EntryForm from './components/EntryForm';
import Heatmap from './components/Heatmap';
import EntryList from './components/EntryList';
import SearchBar from './components/SearchBar';
import CommitModal from './components/CommitModal';
import Stats from './components/Stats';
import {
  getEntries,
  addEntry as saveEntry,
  deleteEntry as removeEntry,
  saveEntries,
} from './utils/storage';
import { generateDummyEntries } from './utils/dummyData';

// Helper to group entries by their date string (YYYY-MM-DD)
function groupEntriesByDate(entries) {
  return entries.reduce((acc, entry) => {
    if (!acc[entry.date]) {
      acc[entry.date] = [];
    }
    acc[entry.date].push(entry);
    return acc;
  }, {});
}

// Filter entries based on a query string.  The query may contain hashtags
// (e.g. #fitness) to filter by tags, plain words to search within
// commit messages and partial hashes to match the start of a commit
// hash.  All tokens must be satisfied for an entry to remain.
function filterEntries(entries, query) {
  if (!query || query.trim().length === 0) return entries;
  const tokens = query.trim().split(/\s+/);
  const tags = tokens.filter((t) => t.startsWith('#')).map((t) => t.substring(1).toLowerCase());
  const others = tokens.filter((t) => !t.startsWith('#')).map((t) => t.toLowerCase());
  return entries.filter((entry) => {
    // Tag filtering: entry.tags must include all specified tags
    if (tags.length > 0) {
      if (!entry.tags || entry.tags.length === 0) return false;
      const entryTags = entry.tags.map((t) => t.toLowerCase());
      if (!tags.every((tag) => entryTags.includes(tag))) return false;
    }
    // Keyword/hash filtering
    if (others.length > 0) {
      const message = (entry.text || '').toLowerCase();
      const hash = (entry.hash || entry.id || '').toLowerCase();
      for (const token of others) {
        // A token matches if it appears in the message or the hash starts with it
        const inMessage = message.includes(token);
        const inHash = hash.startsWith(token);
        if (!inMessage && !inHash) {
          return false;
        }
      }
    }
    return true;
  });
}

function App() {
  // All stored commits (each is a commit object)
  const [entries, setEntries] = useState([]);
  // Currently selected day (ISO date string)
  const [selectedDate, setSelectedDate] = useState(null);
  // Search query string typed by the user
  const [searchQuery, setSearchQuery] = useState('');
  // Currently selected commit for the modal
  const [selectedCommit, setSelectedCommit] = useState(null);

  // On mount: load entries from storage. If none exist, populate dummy data.
  useEffect(() => {
    const stored = getEntries();
    if (!stored || stored.length === 0) {
      const dummy = generateDummyEntries();
      saveEntries(dummy);
      setEntries(dummy);
    } else {
      setEntries(stored);
    }
  }, []);

  // Add a new commit. Save it then reload from storage and update selected date.
  const handleAddEntry = (entry) => {
    saveEntry(entry);
    setEntries(getEntries());
    setSelectedDate(entry.date);
  };

  // Delete a commit by id
  const handleDeleteEntry = (id) => {
    removeEntry(id);
    setEntries(getEntries());
  };

  // Filter entries based on the search query
  const visibleEntries = filterEntries(entries, searchQuery);
  const grouped = groupEntriesByDate(visibleEntries);

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <div className="max-w-5xl mx-auto p-4">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-semibold">LifeGit</h1>
          {/* Placeholder for settings or future actions */}
        </div>
        <SearchBar entries={entries} onSearch={setSearchQuery} />
        <div className="mt-6">
          <Heatmap entries={visibleEntries} onSelectDate={setSelectedDate} />
        </div>
        <Stats entries={entries} />
        <EntryForm onAdd={handleAddEntry} />
        {selectedDate && (
          <EntryList
            date={selectedDate}
            entries={grouped[selectedDate] || []}
            onDelete={handleDeleteEntry}
            onSelect={setSelectedCommit}
          />
        )}
        <CommitModal commit={selectedCommit} onClose={() => setSelectedCommit(null)} />
      </div>
    </div>
  );
}

export default App;