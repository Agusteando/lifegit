// Storage helper for persisting LifeGit entries in localStorage.

const STORAGE_KEY = 'lifegit_entries_v1';

/**
 * Retrieve all entries from localStorage.  The returned array contains
 * objects with the following fields:
 *   id        – unique identifier for the entry
 *   text      – the raw free‑form text
 *   timestamp – ISO 8601 timestamp of when the entry was saved
 *   date      – YYYY-MM-DD string for grouping by calendar day
 *   tags      – array of lowercase tag names (without the leading #)
 *
 * @returns {Array<Object>} the list of stored entries
 */
export function getEntries() {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Failed to parse stored entries', err);
    return [];
  }
}

/**
 * Persist an array of entries to localStorage.
 *
 * @param {Array<Object>} entries
 */
export function saveEntries(entries) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
  } catch (err) {
    console.error('Failed to save entries', err);
  }
}

/**
 * Append a new entry to storage.  Existing entries are retrieved,
 * the new one is pushed onto the array, and the array is saved back.
 *
 * @param {Object} entry
 */
export function addEntry(entry) {
  const entries = getEntries();
  entries.push(entry);
  saveEntries(entries);
}

/**
 * Remove an entry by its id.
 *
 * @param {string} id
 */
export function deleteEntry(id) {
  const entries = getEntries().filter((e) => e.id !== id);
  saveEntries(entries);
}

/**
 * Update an existing entry.  Matches by id and replaces the
 * corresponding object.  If the entry does not exist, nothing happens.
 *
 * @param {Object} updated
 */
export function updateEntry(updated) {
  const entries = getEntries().map((e) => (e.id === updated.id ? updated : e));
  saveEntries(entries);
}

/**
 * Export all entries as a JSON string.  Users can copy this string
 * elsewhere to back up their logs.  The returned string is pretty
 * formatted for readability.
 */
export function exportEntries() {
  const entries = getEntries();
  return JSON.stringify(entries, null, 2);
}

/**
 * Import entries from a JSON string.  Any existing entries in storage
 * will be replaced by the imported ones.  Returns a boolean indicating
 * success.
 *
 * @param {string} json
 */
export function importEntries(json) {
  try {
    const parsed = JSON.parse(json);
    if (Array.isArray(parsed)) {
      saveEntries(parsed);
      return true;
    }
    return false;
  } catch (err) {
    console.error('Failed to import entries', err);
    return false;
  }
}