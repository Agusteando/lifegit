// Momentum computation utilities for LifeGit.  The goal of the
// momentum score is to reward recent activity while not punishing
// occasional gaps too harshly.  We use an exponential decay so that
// logs from today carry more weight than logs from a week ago, but
// older logs still contribute a little.

/**
 * Compute the number of whole days that have elapsed since the given date.
 *
 * @param {string} dateStr a date in ISO YYYY-MM-DD format
 * @returns {number} days since dateStr (0 if today)
 */
export function daysSinceDate(dateStr) {
  const today = new Date();
  // normalise to midnight to avoid issues around daylight savings
  const target = new Date(dateStr + 'T00:00:00');
  const diffMs = today - target;
  return Math.floor(diffMs / (1000 * 60 * 60 * 24));
}

/**
 * Compute a momentum score based on an array of entries.  Each entry
 * contributes a weight of 0.9^d where d is the number of days ago it
 * occurred.  The score is the mean of the weights, yielding a value
 * between 0 (no activity) and 1 (logs all today).  If there are no
 * entries the score is 0.
 *
 * @param {Array<Object>} entries
 */
export function computeMomentum(entries) {
  if (!entries || entries.length === 0) return 0;
  let totalWeight = 0;
  let totalEntries = 0;
  const today = new Date();
  entries.forEach((entry) => {
    // parse date string as midnight local time
    const date = new Date(entry.date + 'T00:00:00');
    const diffDays = Math.floor((today - date) / (1000 * 60 * 60 * 24));
    const weight = Math.pow(0.9, diffDays);
    totalWeight += weight;
    totalEntries += 1;
  });
  return totalWeight / totalEntries;
}