// Generate dummy LifeGit entries spanning the last two months.  Each entry
// represents a commit and contains a hash, message, timestamp, date and tags.

/**
 * Utility to generate a short pseudo hash.  It produces a seven‑character
 * hexadecimal string similar to a Git abbreviated SHA.
 */
function generateHash() {
  return Math.random().toString(16).substring(2, 9);
}

/**
 * Return an array of dummy entries covering roughly the last 60 days.  The
 * pattern includes periods of high activity, deliberate gaps and rebounds
 * so that the heatmap and momentum widgets demonstrate realistic
 * behaviour.  Each commit message includes hashtags pulled from a small
 * vocabulary to allow tag filtering.
 */
export function generateDummyEntries() {
  const entries = [];
  const now = new Date();
  // Array of possible messages with associated tags
  const samples = [
    { message: 'Morning workout at the gym', tags: ['fitness'] },
    { message: 'Shipped feature alpha', tags: ['shipping'] },
    { message: 'Read 20 pages of a book', tags: ['reading'] },
    { message: 'Went for a 5km run', tags: ['fitness'] },
    { message: 'Fixed bugs and refactored code', tags: ['shipping'] },
    { message: 'Meditation and journaling', tags: ['mindfulness'] },
    { message: 'Deployed new version to production', tags: ['shipping'] },
    { message: 'Yoga session', tags: ['fitness'] },
    { message: 'Brainstormed future goals', tags: ['planning'] },
    { message: 'Debugged tricky issue', tags: ['shipping'] },
  ];
  // Loop through approximately the last two months (60 days)
  for (let i = 59; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(now.getDate() - i);
    const dateStr = date.toISOString().split('T')[0];
    // Determine the number of commits for this day based on a rough pattern
    let commitCount;
    if (i > 55) {
      // At the very beginning of the period: high activity
      commitCount = 3;
    } else if (i > 45) {
      // Cooldown period with sporadic activity
      commitCount = i % 3 === 0 ? 0 : 1;
    } else if (i > 35) {
      // Intense rebound
      commitCount = 4;
    } else if (i > 25) {
      // Moderate activity
      commitCount = 2;
    } else if (i > 15) {
      // Intentional break: mostly gaps
      commitCount = 0;
    } else if (i > 5) {
      // Building momentum again
      commitCount = 3;
    } else {
      // Recent week: varied activity
      commitCount = 1 + (i % 3);
    }
    for (let c = 0; c < commitCount; c++) {
      // Pick a random sample message and tags
      const sample = samples[Math.floor(Math.random() * samples.length)];
      const nowDate = new Date(date);
      // Stagger commit times within the day
      nowDate.setHours(8 + c * 3);
      nowDate.setMinutes(Math.floor(Math.random() * 60));
      const timestamp = nowDate.toISOString();
      entries.push({
        id: generateHash(),
        hash: generateHash(),
        text: sample.message + ' #' + sample.tags.join(' #'),
        timestamp,
        date: dateStr,
        tags: sample.tags,
      });
    }
  }
  return entries;
}