import React from 'react';

/**
 * Displays all entries for a given date in a simple list.  Each entry
 * shows the time it was logged, the free‑form text and any hashtags.
 * A delete button allows removal of the entry.  Entries are shown
 * newest first.
 */
function EntryList({ date, entries, onDelete, onSelect }) {
  // Sort entries in reverse chronological order by timestamp
  const sorted = [...entries].sort(
    (a, b) => new Date(b.timestamp) - new Date(a.timestamp)
  );

  return (
    <div className="mt-8 p-4 bg-white rounded shadow">
      <h2 className="text-xl font-semibold mb-4">{date}</h2>
      {sorted.length === 0 && (
        <p className="text-gray-500">No commits for this day.</p>
      )}
      {sorted.map((entry) => {
        const hash = entry.hash || entry.id;
        const truncated = hash.slice(0, 7);
        return (
          <div
            key={entry.id}
            className="border-b border-gray-200 last:border-b-0 py-3 flex justify-between items-start cursor-pointer"
            onClick={() => onSelect && onSelect(entry)}
          >
            <div className="flex-1 mr-4">
              <p className="text-sm text-gray-500 flex items-center">
                <span className="font-mono" title={hash}>{truncated}</span>
                <span className="ml-2">
                  {new Date(entry.timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </p>
              <p className="mt-1 whitespace-pre-wrap">{entry.text}</p>
              {entry.tags && entry.tags.length > 0 && (
                <div className="mt-2">
                  {entry.tags.map((tag) => (
                    <span
                      key={tag}
                      className="inline-block mr-2 mb-1 px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDelete(entry.id);
              }}
              className="text-red-500 hover:text-red-700 ml-2 shrink-0"
            >
              Delete
            </button>
          </div>
        );
      })}
    </div>
  );
}

export default EntryList;