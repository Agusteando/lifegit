import React from 'react';

/**
 * A modal that displays detailed information about a single commit.  It
 * presents the full hash, timestamp, message and tags.  A copy button
 * allows the user to copy the hash to the clipboard.  The modal is
 * positioned above a semi‑transparent backdrop and closes when the
 * `onClose` callback is invoked.
 */
function CommitModal({ commit, onClose }) {
  if (!commit) return null;
  const hash = commit.hash || commit.id;
  const time = new Date(commit.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });
  // Copy the hash to the clipboard
  function handleCopy() {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(hash);
    }
  }
  return (
    <div className="fixed inset-0 z-20 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white p-6 rounded shadow-lg max-w-md w-full">
        <h3 className="text-lg font-semibold mb-4">Commit Details</h3>
        <p className="mb-2">
          <span className="font-semibold">Hash:</span>{' '}
          <span className="font-mono break-all">{hash}</span>
          <button
            onClick={handleCopy}
            className="ml-3 px-2 py-1 text-xs text-blue-600 border border-blue-600 rounded hover:bg-blue-50"
          >
            Copy
          </button>
        </p>
        <p className="mb-2">
          <span className="font-semibold">Date:</span> {commit.date}
        </p>
        <p className="mb-4">
          <span className="font-semibold">Time:</span> {time}
        </p>
        <p className="whitespace-pre-wrap mb-4">{commit.text}</p>
        {commit.tags && commit.tags.length > 0 && (
          <div className="mb-4">
            {commit.tags.map((tag) => (
              <span
                key={tag}
                className="inline-block mr-2 mb-2 px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}
        <div className="text-right">
          <button
            onClick={onClose}
            className="px-3 py-1 bg-gray-200 hover:bg-gray-300 rounded"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

export default CommitModal;