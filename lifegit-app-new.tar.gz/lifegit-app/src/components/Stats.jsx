import React from 'react';
import { computeMomentum, daysSinceDate } from '../utils/momentum';

/**
 * Presents high‑level statistics about the user’s logging activity.  A
 * friendly message indicates how long it has been since the last entry
 * and a momentum score summarises recent activity.  Momentum decays
 * exponentially so lapses don’t reset it to zero.
 */
function Stats({ entries }) {
  if (!entries || entries.length === 0) {
    return (
      <div className="mt-8 p-4 bg-white rounded shadow">
        <p className="text-gray-500">No entries yet. Start logging to build your momentum.</p>
      </div>
    );
  }
  // Find the most recent entry by timestamp
  const lastEntry = entries.reduce((latest, entry) => {
    return new Date(entry.timestamp) > new Date(latest.timestamp) ? entry : latest;
  }, entries[0]);
  const daysSince = daysSinceDate(lastEntry.date);
  const momentum = computeMomentum(entries);

  let message;
  if (daysSince === 0) {
    message = 'You logged today. Keep it up!';
  } else if (daysSince === 1) {
    message = 'You logged yesterday. Momentum is still alive.';
  } else {
    // When the user has been away for more than one day but still has a non‑zero
    // momentum, encourage them gently rather than focusing on the gap.
    if (momentum > 0) {
      message = 'Momentum paused but never lost.';
    } else {
      message = `Welcome back! Your last log was ${daysSince} days ago.`;
    }
  }

  return (
    <div className="mt-8 p-4 bg-white rounded shadow">
      <p className="font-medium">{message}</p>
      <p className="mt-2 text-sm text-gray-600">
        Momentum score: <span className="font-semibold">{momentum.toFixed(2)}</span>
      </p>
    </div>
  );
}

export default Stats;