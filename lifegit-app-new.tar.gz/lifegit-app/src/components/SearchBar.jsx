import React, { useState, useEffect } from 'react';

/**
 * A search bar that filters commits by tag, keyword or hash.  Users can
 * type multiple tokens separated by spaces.  Hashtags (e.g. `#fitness`)
 * filter by tag, plain words search the commit messages and partial
 * hashes filter by matching the start of a commit hash.  When the
 * current token looks like a partial hash, suggestions for matching
 * hashes from existing entries are shown and can be selected.
 */
function SearchBar({ entries, onSearch }) {
  const [input, setInput] = useState('');
  const [suggestions, setSuggestions] = useState([]);

  useEffect(() => {
    onSearch(input);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [input]);

  /**
   * When the input changes we update the search query and compute
   * potential hash suggestions based on the last token.
   */
  function handleChange(e) {
    const value = e.target.value;
    setInput(value);
    const tokens = value.trim().split(/\s+/);
    const lastToken = tokens[tokens.length - 1];
    // Only suggest hashes when the last token doesn't start with a '#' and is non‑empty
    if (lastToken && lastToken.length > 0 && !lastToken.startsWith('#')) {
      const lower = lastToken.toLowerCase();
      // Collect all hashes from entries (fall back to id if hash missing)
      const hashes = entries.map((e) => (e.hash || e.id || '').toLowerCase());
      const unique = Array.from(new Set(hashes));
      const matches = unique.filter((h) => h.startsWith(lower)).slice(0, 5);
      setSuggestions(matches);
    } else {
      setSuggestions([]);
    }
  }

  /**
   * Replace the last token in the input with the selected suggestion.
   */
  function handleSuggestionClick(hash) {
    const tokens = input.trim().split(/\s+/).filter((t) => t.length > 0);
    // Remove the last token
    tokens.pop();
    tokens.push(hash);
    const newVal = tokens.join(' ');
    setInput(newVal);
    setSuggestions([]);
    onSearch(newVal);
  }

  return (
    <div className="mt-6 relative">
      <input
        type="text"
        value={input}
        onChange={handleChange}
        placeholder="Search by tag (#fitness), keyword, or hash"
        className="w-full border border-gray-300 p-2 rounded focus:outline-none focus:ring focus:ring-blue-300"
      />
      {suggestions.length > 0 && (
        <ul className="absolute z-10 left-0 right-0 bg-white border border-gray-200 rounded mt-1 shadow text-sm">
          {suggestions.map((s, idx) => (
            <li
              key={s + idx}
              className="px-3 py-1 hover:bg-gray-100 cursor-pointer font-mono"
              onClick={() => handleSuggestionClick(s)}
            >
              {s}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default SearchBar;