import React, { useState } from 'react';

/**
 * The entry form allows users to write free‑form text about their day.
 * Hashtags are automatically extracted when the entry is saved.
 * A new entry object is passed up via the onAdd callback.
 */
function EntryForm({ onAdd }) {
  // An array of commit objects, each with its own message field
  const [commits, setCommits] = useState([{ message: '' }]);

  // Parse hashtags from a string, returning an array of tag names (no #)
  function parseTags(str) {
    const regex = /#[\w-]+/g;
    const matches = str.match(regex) || [];
    return matches.map((tag) => tag.substring(1).toLowerCase());
  }

  // Add an empty commit input field
  function addCommitField() {
    setCommits([...commits, { message: '' }]);
  }

  // Remove a commit input field at a specific index
  function removeCommitField(index) {
    setCommits(commits.filter((_, i) => i !== index));
  }

  // Update the message of a commit
  function updateCommit(index, value) {
    const next = commits.map((c, i) => (i === index ? { ...c, message: value } : c));
    setCommits(next);
  }

  // Submit all commits as separate entries
  function handleSubmit(e) {
    e.preventDefault();
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    commits.forEach((commit) => {
      const trimmed = commit.message.trim();
      if (!trimmed) return;
      const tags = parseTags(trimmed);
      const id = Date.now().toString(36) + Math.random().toString(36).substring(2);
      const hash = Math.random().toString(16).substring(2, 9);
      const entry = {
        id,
        hash,
        text: trimmed,
        timestamp: new Date().toISOString(),
        date: dateStr,
        tags,
      };
      onAdd(entry);
    });
    // Reset to a single empty commit field
    setCommits([{ message: '' }]);
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white p-4 rounded shadow">
      <h2 className="text-xl font-semibold mb-3">Add New Log / Commit Group</h2>
      {commits.map((commit, index) => (
        <div key={index} className="mb-3 flex items-start">
          <textarea
            className="w-full border border-gray-300 p-2 rounded focus:outline-none focus:ring focus:ring-blue-300"
            rows="2"
            value={commit.message}
            placeholder={`Commit message ${index + 1}`}
            onChange={(e) => updateCommit(index, e.target.value)}
          />
          {commits.length > 1 && (
            <button
              type="button"
              onClick={() => removeCommitField(index)}
              className="ml-2 mt-1 text-red-500 hover:text-red-700"
              title="Remove this commit"
            >
              ×
            </button>
          )}
        </div>
      ))}
      <div className="flex justify-between items-center mb-3">
        <button
          type="button"
          onClick={addCommitField}
          className="text-blue-600 hover:text-blue-800"
        >
          + Add Commit
        </button>
        <button
          type="submit"
          className="bg-blue-500 hover:bg-blue-600 text-white font-medium px-4 py-2 rounded"
        >
          Commit to LifeGit
        </button>
      </div>
    </form>
  );
}

export default EntryForm;