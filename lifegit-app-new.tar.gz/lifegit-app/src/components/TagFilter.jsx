import React, { useState } from 'react';

/**
 * A simple input field that lets users filter their timeline by tags.
 * Type one or more #tags separated by spaces.  When the input changes,
 * the onChange callback receives an array of lowercase tag names.  If
 * the input is empty, an empty array is sent to clear the filter.
 */
function TagFilter({ onChange }) {
  const [text, setText] = useState('');

  /**
   * Parse the raw input string into separate tag and keyword filters.  Tags
   * start with a leading # and may contain letters, numbers, underscores
   * and hyphens.  Everything else is treated as a plain keyword.  The
   * function returns an object with two arrays: `tags` and `keywords`.
   */
  function parseQuery(str) {
    const tokens = str
      .trim()
      .split(/\s+/)
      .filter(Boolean);
    const tags = [];
    const keywords = [];
    tokens.forEach((tok) => {
      if (tok.startsWith('#')) {
        tags.push(tok.substring(1).toLowerCase());
      } else {
        keywords.push(tok.toLowerCase());
      }
    });
    return { tags, keywords };
  }

  function handleChange(e) {
    const val = e.target.value;
    setText(val);
    const filters = parseQuery(val);
    onChange(filters);
  }

  return (
    <div className="mt-6">
      <input
        type="text"
        value={text}
        onChange={handleChange}
        placeholder="Search by tag (#fitness) or keyword (gym)"
        className="w-full border border-gray-300 p-2 rounded focus:outline-none focus:ring focus:ring-blue-300"
      />
    </div>
  );
}

export default TagFilter;