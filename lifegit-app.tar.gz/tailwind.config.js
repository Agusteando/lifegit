/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './index.html',
    './src/**/*.{js,jsx,ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        // Custom heatmap colors used in the calendar component.
        'heat-0': '#e5e7eb', // gray-200
        'heat-1': '#d1fae5', // green-50
        'heat-2': '#6ee7b7', // green-300
        'heat-3': '#34d399', // green-400
        'heat-4': '#059669', // green-600
      },
    },
  },
  plugins: [],
};