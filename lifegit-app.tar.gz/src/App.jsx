import React, { useState, useEffect } from 'react';
import EntryForm from './components/EntryForm';
import Heatmap from './components/Heatmap';
import EntryList from './components/EntryList';
import TagFilter from './components/TagFilter';
import Stats from './components/Stats';
import {
  getEntries,
  addEntry as saveEntry,
  deleteEntry as removeEntry,
} from './utils/storage';

// Helper to group entries by their date string (YYYY-MM-DD)
function groupEntriesByDate(entries) {
  return entries.reduce((acc, entry) => {
    if (!acc[entry.date]) {
      acc[entry.date] = [];
    }
    acc[entry.date].push(entry);
    return acc;
  }, {});
}

// Filter entries based on an array of tags. Only entries that contain all tags survive.
function filterEntriesByTags(entries, filterTags) {
  if (!filterTags || filterTags.length === 0) {
    return entries;
  }
  return entries.filter((entry) => {
    if (!entry.tags || entry.tags.length === 0) return false;
    // all filterTags must be included in entry.tags
    return filterTags.every((tag) => entry.tags.includes(tag));
  });
}

function App() {
  // All stored entries
  const [entries, setEntries] = useState([]);
  // Currently selected day (ISO date string) for viewing entries
  const [selectedDate, setSelectedDate] = useState(null);
  // Tags used to filter displayed entries/heatmap
  const [filterTags, setFilterTags] = useState([]);

  // Load entries from localStorage on first render
  useEffect(() => {
    setEntries(getEntries());
  }, []);

  // Add a new entry. Save it then reload from storage to keep state consistent.
  const handleAddEntry = (entry) => {
    saveEntry(entry);
    // Set the selected date to the entry's date so that after adding
    // the user sees their new log in the list immediately.
    setSelectedDate(entry.date);
    setEntries(getEntries());
  };

  // Delete an entry by id and refresh state
  const handleDeleteEntry = (id) => {
    removeEntry(id);
    setEntries(getEntries());
  };

  // Apply tag filters before grouping for the heatmap and list
  const visibleEntries = filterEntriesByTags(entries, filterTags);
  const grouped = groupEntriesByDate(visibleEntries);

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <div className="max-w-4xl mx-auto p-4">
        <h1 className="text-3xl font-semibold mb-6">LifeGit</h1>
        <EntryForm onAdd={handleAddEntry} />
        <TagFilter onChange={setFilterTags} />
        <div className="mt-8">
          <Heatmap entries={visibleEntries} onSelectDate={setSelectedDate} />
        </div>
        <Stats entries={entries} />
        {selectedDate && (
          <EntryList
            date={selectedDate}
            entries={grouped[selectedDate] || []}
            onDelete={handleDeleteEntry}
          />
        )}
      </div>
    </div>
  );
}

export default App;