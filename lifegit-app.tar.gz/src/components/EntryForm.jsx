import React, { useState } from 'react';

/**
 * The entry form allows users to write free‑form text about their day.
 * Hashtags are automatically extracted when the entry is saved.
 * A new entry object is passed up via the onAdd callback.
 */
function EntryForm({ onAdd }) {
  const [text, setText] = useState('');

  // Extract hashtags from the text.  The regex captures words prefaced
  // by a hash (#) and allows letters, numbers, underscores and hyphens.
  function parseTags(str) {
    const regex = /#[\w-]+/g;
    const matches = str.match(regex) || [];
    return matches.map((tag) => tag.substring(1).toLowerCase());
  }

  function handleSubmit(e) {
    e.preventDefault();
    const trimmed = text.trim();
    if (!trimmed) return;
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const tags = parseTags(trimmed);
    const newEntry = {
      id: Date.now().toString(36) + Math.random().toString(36).substring(2),
      text: trimmed,
      timestamp: now.toISOString(),
      date: dateStr,
      tags,
    };
    onAdd(newEntry);
    setText('');
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white p-4 rounded shadow">
      <textarea
        className="w-full border border-gray-300 p-2 rounded mb-3 focus:outline-none focus:ring focus:ring-blue-300"
        rows="3"
        value={text}
        placeholder="What happened today? Add #tags to organise your thoughts..."
        onChange={(e) => setText(e.target.value)}
      />
      <button
        type="submit"
        className="inline-block bg-blue-500 hover:bg-blue-600 text-white font-medium px-4 py-2 rounded"
      >
        Add Entry
      </button>
    </form>
  );
}

export default EntryForm;