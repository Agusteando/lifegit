import React, { useState } from 'react';

/**
 * A simple input field that lets users filter their timeline by tags.
 * Type one or more #tags separated by spaces.  When the input changes,
 * the onChange callback receives an array of lowercase tag names.  If
 * the input is empty, an empty array is sent to clear the filter.
 */
function TagFilter({ onChange }) {
  const [text, setText] = useState('');

  function parseTags(str) {
    const regex = /#[\w-]+/g;
    const matches = str.match(regex) || [];
    return matches.map((tag) => tag.substring(1).toLowerCase());
  }

  function handleChange(e) {
    const val = e.target.value;
    setText(val);
    const tags = parseTags(val);
    onChange(tags);
  }

  return (
    <div className="mt-6">
      <input
        type="text"
        value={text}
        onChange={handleChange}
        placeholder="Filter by tags (e.g., #fitness #reading)"
        className="w-full border border-gray-300 p-2 rounded focus:outline-none focus:ring focus:ring-blue-300"
      />
    </div>
  );
}

export default TagFilter;