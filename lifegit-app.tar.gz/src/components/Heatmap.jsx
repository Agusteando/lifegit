import React from 'react';
import CalendarHeatmap from 'react-calendar-heatmap';
import 'react-calendar-heatmap/dist/styles.css';

/**
 * A wrapper around react-calendar-heatmap that maps LifeGit entries
 * into the values expected by the component.  Clicking on a day
 * triggers the onSelectDate callback with the selected date.
 */
function Heatmap({ entries, onSelectDate }) {
  // Compute counts per day as required by react-calendar-heatmap.
  const counts = {};
  entries.forEach((entry) => {
    counts[entry.date] = (counts[entry.date] || 0) + 1;
  });
  const values = Object.keys(counts).map((date) => ({ date, count: counts[date] }));

  // Determine the start date one year ago from today.  The library will
  // automatically handle missing days.
  const endDate = new Date();
  const startDate = new Date();
  startDate.setFullYear(endDate.getFullYear() - 1);

  return (
    <div className="overflow-x-auto">
      <CalendarHeatmap
        startDate={startDate}
        endDate={endDate}
        values={values}
        classForValue={(value) => {
          if (!value || value.count === 0) {
            return 'color-empty';
          }
          // Map counts to colour classes.  Adjust thresholds as desired.
          if (value.count >= 4) return 'color-scale-4';
          if (value.count >= 3) return 'color-scale-3';
          if (value.count >= 2) return 'color-scale-2';
          return 'color-scale-1';
        }}
        tooltipDataAttrs={(value) => {
          if (!value || !value.date) return {};
          const count = value.count || 0;
          const plural = count === 1 ? 'entry' : 'entries';
          return { 'data-tip': `${value.date}: ${count} ${plural}` };
        }}
        onClick={(value) => {
          if (value && value.date) {
            onSelectDate(value.date);
          }
        }}
        showWeekdayLabels={true}
      />
    </div>
  );
}

export default Heatmap;